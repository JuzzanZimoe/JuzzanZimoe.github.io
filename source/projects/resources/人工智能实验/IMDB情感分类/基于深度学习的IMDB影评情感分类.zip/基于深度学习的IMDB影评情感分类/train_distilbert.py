import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'
import pandas as pd
import torch
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset

# ================== 配置 ==================
MODEL_NAME = 'distilbert-base-uncased'
MAX_LEN = 200           # BERT 截断长度，200 已经足够
TRAIN_PATH = "question2_train.csv"
TEST_PATH = "question2_test.csv"
BATCH_SIZE = 16          # CPU 上用小 batch
EPOCHS = 2               # 2 个 epoch 也能过得去

# ================== 加载数据 ==================
train_df = pd.read_csv(TRAIN_PATH)
test_df = pd.read_csv(TEST_PATH)

# 划分验证集（从训练集拆 20%）
X_train, X_val, y_train, y_val = train_test_split(
    train_df['text'], train_df['label'], test_size=0.2, random_state=42, stratify=train_df['label']
)

# ================== 转换为 HuggingFace Dataset ==================
tokenizer = DistilBertTokenizer.from_pretrained(MODEL_NAME)

def tokenize_function(examples):
    return tokenizer(examples['text'], padding='max_length', truncation=True, max_length=MAX_LEN)

train_dataset = Dataset.from_dict({'text': X_train.tolist(), 'label': y_train.tolist()})
val_dataset = Dataset.from_dict({'text': X_val.tolist(), 'label': y_val.tolist()})
test_dataset = Dataset.from_dict({'text': test_df['text'].tolist(), 'label': test_df['label'].tolist()})

train_dataset = train_dataset.map(tokenize_function, batched=True)
val_dataset = val_dataset.map(tokenize_function, batched=True)
test_dataset = test_dataset.map(tokenize_function, batched=True)

# 设置数据集格式
train_dataset.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])
val_dataset.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])
test_dataset.set_format(type='torch', columns=['input_ids', 'attention_mask', 'label'])

# ================== 加载预训练模型 ==================
model = DistilBertForSequenceClassification.from_pretrained(MODEL_NAME, num_labels=2)

# ================== 训练参数 ==================
training_args = TrainingArguments(
    output_dir='./results',
    per_device_train_batch_size=BATCH_SIZE,
    per_device_eval_batch_size=BATCH_SIZE,
    num_train_epochs=EPOCHS,
    eval_strategy='epoch',
    save_strategy='epoch',
    logging_dir='./logs',
    logging_steps=50,
    learning_rate=2e-5,
    weight_decay=0.01,
    load_best_model_at_end=True,
    metric_for_best_model='accuracy',
    report_to='none'   # 不登陆任何平台
)

def compute_metrics(eval_pred):
    logits, labels = eval_pred
    predictions = np.argmax(logits, axis=-1)
    accuracy = np.mean(predictions == labels)
    return {'accuracy': accuracy}

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    compute_metrics=compute_metrics
)

# ================== 开始训练 ==================
print("开始微调 DistilBERT...")
trainer.train()

# ================== 测试集评估 ==================
predictions = trainer.predict(test_dataset)
preds = np.argmax(predictions.predictions, axis=1)
labels = predictions.label_ids

print("\nDistilBERT 测试集分类报告:")
print(classification_report(labels, preds, target_names=['Negative', 'Positive']))

# 混淆矩阵
cm = confusion_matrix(labels, preds)
plt.figure(figsize=(5,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Neg','Pos'], yticklabels=['Neg','Pos'])
plt.xlabel('Predicted'); plt.ylabel('True')
plt.title('DistilBERT Confusion Matrix')
plt.savefig('cm_distilbert.png', dpi=150)
plt.close()
print("混淆矩阵已保存为 cm_distilbert.png")