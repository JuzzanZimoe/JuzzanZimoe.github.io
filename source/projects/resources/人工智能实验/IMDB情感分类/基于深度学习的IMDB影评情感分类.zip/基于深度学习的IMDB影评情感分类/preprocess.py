import pandas as pd
import numpy as np
import re
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from collections import Counter
from tqdm import tqdm
from bs4 import BeautifulSoup

# ======================== 配置 ========================
TRAIN_PATH = "question2_train.csv"
TEST_PATH = "question2_test.csv"
MAX_LEN = 200               # 统一序列长度 (你可以之后调整)
MIN_WORD_FREQ = 5           # 词最少出现次数，低于此则视为 <UNK>
BATCH_SIZE = 64             # 训练时每个 batch 的大小
DEVICE = torch.device('cpu')

# ======================== 1. 加载数据 ========================
print("正在加载数据...")
train_df = pd.read_csv(TRAIN_PATH)
test_df  = pd.read_csv(TEST_PATH)

# ======================== 2. 文本清洗函数 ========================
def clean_text(text):
    # 去掉 HTML 标签
    text = BeautifulSoup(text, "html.parser").get_text()
    # 只保留英文字母，并转小写
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = text.lower()
    # 去掉多余空白
    text = re.sub(r'\s+', ' ', text).strip()
    return text

print("清洗文本中...")
tqdm.pandas(desc="清洗训练集")
train_df['clean'] = train_df['text'].progress_apply(clean_text)
tqdm.pandas(desc="清洗测试集")
test_df['clean'] = test_df['text'].progress_apply(clean_text)

# ======================== 3. 分词 & 构建词表 ========================
def tokenize(text):
    # 因为已经清洗干净，直接按空格分即可
    return text.split()

print("分词并构建词表...")
# 统计训练集中所有词的频率
word_counter = Counter()
for text in tqdm(train_df['clean'], desc="统计词频"):
    word_counter.update(tokenize(text))

# 按频率过滤，并加入特殊标记
vocab = {'<PAD>': 0, '<UNK>': 1}
for word, freq in word_counter.items():
    if freq >= MIN_WORD_FREQ:
        vocab[word] = len(vocab)

print(f"词表大小（含特殊标记）: {len(vocab)}")

# 反向映射（调试用）
idx2word = {idx: word for word, idx in vocab.items()}

# ======================== 4. 编码 & 填充/截断 ========================
def encode(text, vocab, max_len):
    tokens = tokenize(text)
    ids = [vocab.get(token, vocab['<UNK>']) for token in tokens]
    # 截断
    if len(ids) > max_len:
        ids = ids[:max_len]
    # 填充
    else:
        ids += [vocab['<PAD>']] * (max_len - len(ids))
    return ids

print("编码并填充序列...")
tqdm.pandas(desc="编码训练集")
train_df['ids'] = train_df['clean'].progress_apply(lambda x: encode(x, vocab, MAX_LEN))
tqdm.pandas(desc="编码测试集")
test_df['ids'] = test_df['clean'].progress_apply(lambda x: encode(x, vocab, MAX_LEN))

# 转换为 numpy 数组（便于后续 Dataset 使用）
X_train = np.array(train_df['ids'].tolist(), dtype=np.int64)
y_train = train_df['label'].values.astype(np.int64)
X_test  = np.array(test_df['ids'].tolist(), dtype=np.int64)
y_test  = test_df['label'].values.astype(np.int64)

# ======================== 5. 划分训练集 / 验证集 ========================
X_train, X_val, y_train, y_val = train_test_split(
    X_train, y_train,
    test_size=0.2,
    random_state=42,
    stratify=y_train
)

print(f"\n训练集: {X_train.shape}, 验证集: {X_val.shape}, 测试集: {X_test.shape}")

# ======================== 6. 定义 PyTorch Dataset ========================
class IMDBDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.LongTensor(X)
        self.y = torch.LongTensor(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# 构建 DataLoader
train_dataset = IMDBDataset(X_train, y_train)
val_dataset   = IMDBDataset(X_val, y_val)
test_dataset  = IMDBDataset(X_test, y_test)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader   = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
test_loader  = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

print("\n✅ 数据预处理全部完成！")
print(f"训练批次数: {len(train_loader)}, 验证批次数: {len(val_loader)}, 测试批次数: {len(test_loader)}")
print("现在可以开始建模训练了。")