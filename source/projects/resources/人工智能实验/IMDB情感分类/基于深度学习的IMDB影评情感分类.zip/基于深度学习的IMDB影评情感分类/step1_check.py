import pandas as pd
import torch
import re
from bs4 import BeautifulSoup

# -------------------- 文件路径（改成你的实际路径）--------------------
TRAIN_PATH = "question2_train.csv"
TEST_PATH  = "question2_test.csv"

# -------------------- 加载数据 --------------------
train_df = pd.read_csv(TRAIN_PATH)
test_df  = pd.read_csv(TEST_PATH)

print("✅ 训练集大小:", train_df.shape)
print("✅ 测试集大小:", test_df.shape)
print("\n训练集前2行（原始）:\n", train_df.head(2))
print("\n标签分布:\n", train_df['label'].value_counts())

# -------------------- 炫技一下：自动清洗一条示例 --------------------
def clean_text(raw_text):
    # 去掉HTML标签
    text = BeautifulSoup(raw_text, "html.parser").get_text()
    # 只保留英文字母，统一小写
    text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
    # 去掉多余空白
    text = re.sub(r'\s+', ' ', text).strip()
    return text

print("\n\n🔧 清洗示例（第一条评论的前200字符）：")
sample_raw = train_df.loc[0, 'text']
sample_clean = clean_text(sample_raw)
print("清洗前:", sample_raw[:200], "...")
print("\n清洗后:", sample_clean[:200], "...")

print("\n🎉 一切正常！环境、数据、清洗函数都没问题。")