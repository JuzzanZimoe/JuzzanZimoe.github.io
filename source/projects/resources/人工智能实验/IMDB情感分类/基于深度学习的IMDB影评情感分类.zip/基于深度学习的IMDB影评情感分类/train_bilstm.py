import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import pandas as pd
import re
from collections import Counter
from bs4 import BeautifulSoup
from tqdm import tqdm
from torch.utils.data import Dataset, DataLoader

# ================== 参数配置 ==================
TRAIN_PATH = "question2_train.csv"
TEST_PATH  = "question2_test.csv"
MAX_LEN = 200
MIN_WORD_FREQ = 5
BATCH_SIZE = 64
EPOCHS = 5
LR = 0.001
EMBEDDING_DIM = 100
HIDDEN_DIM = 128
NUM_LAYERS = 1            # BiLSTM 可以用单层，因为双向本身增强容量
DROPOUT = 0.5
DEVICE = torch.device('cpu')

# ================== 数据预处理（与之前相同） ==================
def clean_text(text):
    text = BeautifulSoup(text, "html.parser").get_text()
    text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
    text = re.sub(r'\s+', ' ', text).strip()
    return text

train_df = pd.read_csv(TRAIN_PATH)
test_df = pd.read_csv(TEST_PATH)

tqdm.pandas(desc="清洗训练集")
train_df['clean'] = train_df['text'].progress_apply(clean_text)
tqdm.pandas(desc="清洗测试集")
test_df['clean'] = test_df['text'].progress_apply(clean_text)

word_counter = Counter()
for text in tqdm(train_df['clean'], desc="统计词频"):
    word_counter.update(text.split())

vocab = {'<PAD>': 0, '<UNK>': 1}
for word, freq in word_counter.items():
    if freq >= MIN_WORD_FREQ:
        vocab[word] = len(vocab)
vocab_size = len(vocab)

def encode(text, vocab, max_len):
    ids = [vocab.get(word, vocab['<UNK>']) for word in text.split()]
    if len(ids) > max_len:
        ids = ids[:max_len]
    else:
        ids.extend([vocab['<PAD>']] * (max_len - len(ids)))
    return ids

tqdm.pandas(desc="编码训练集")
train_df['ids'] = train_df['clean'].progress_apply(lambda x: encode(x, vocab, MAX_LEN))
tqdm.pandas(desc="编码测试集")
test_df['ids'] = test_df['clean'].progress_apply(lambda x: encode(x, vocab, MAX_LEN))

X_train_all = np.array(train_df['ids'].tolist(), dtype=np.int64)
y_train_all = train_df['label'].values.astype(np.int64)
X_test = np.array(test_df['ids'].tolist(), dtype=np.int64)
y_test = test_df['label'].values.astype(np.int64)

X_train, X_val, y_train, y_val = train_test_split(
    X_train_all, y_train_all, test_size=0.2, random_state=42, stratify=y_train_all
)

class IMDBDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.LongTensor(X)
        self.y = torch.LongTensor(y)
    def __len__(self): return len(self.y)
    def __getitem__(self, idx): return self.X[idx], self.y[idx]

train_loader = DataLoader(IMDBDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(IMDBDataset(X_val, y_val), batch_size=BATCH_SIZE, shuffle=False)
test_loader = DataLoader(IMDBDataset(X_test, y_test), batch_size=BATCH_SIZE, shuffle=False)

# ================== BiLSTM 模型 ==================
class BiLSTMModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, num_layers, dropout, num_classes=2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, num_layers=num_layers, batch_first=True,
                            dropout=dropout, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_dim * 2, num_classes)  # 双向所以乘2

    def forward(self, x):
        emb = self.embedding(x)
        lstm_out, _ = self.lstm(emb)
        last_out = lstm_out[:, -1, :]  # (batch, hidden_dim*2)
        out = self.dropout(last_out)
        logits = self.fc(out)
        return logits

model = BiLSTMModel(vocab_size, EMBEDDING_DIM, HIDDEN_DIM, NUM_LAYERS, DROPOUT).to(DEVICE)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LR)

# ================== 训练与评估 ==================
def train_epoch():
    model.train()
    total_loss, correct, total = 0, 0, 0
    for x, y in train_loader:
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        pred = torch.argmax(logits, dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return total_loss / len(train_loader), correct / total

def eval_epoch(loader):
    model.eval()
    total_loss, correct, total = 0, 0, 0
    with torch.no_grad():
        for x, y in loader:
            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item()
            pred = torch.argmax(logits, dim=1)
            correct += (pred == y).sum().item()
            total += y.size(0)
    return total_loss / len(loader), correct / total

train_losses, val_losses = [], []
train_accs, val_accs = [], []

print("开始训练 BiLSTM...")
for epoch in range(1, EPOCHS+1):
    tr_loss, tr_acc = train_epoch()
    vl_loss, vl_acc = eval_epoch(val_loader)
    train_losses.append(tr_loss)
    val_losses.append(vl_loss)
    train_accs.append(tr_acc)
    val_accs.append(vl_acc)
    print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {tr_loss:.4f} Acc: {tr_acc:.4f} | Val Loss: {vl_loss:.4f} Acc: {vl_acc:.4f}")

# 绘制曲线
plt.figure(figsize=(12,4))
plt.subplot(1,2,1)
plt.plot(range(1, EPOCHS+1), train_losses, label='Train Loss')
plt.plot(range(1, EPOCHS+1), val_losses, label='Val Loss')
plt.xlabel('Epoch'); plt.ylabel('Loss'); plt.legend(); plt.title('BiLSTM Loss')
plt.subplot(1,2,2)
plt.plot(range(1, EPOCHS+1), train_accs, label='Train Acc')
plt.plot(range(1, EPOCHS+1), val_accs, label='Val Acc')
plt.xlabel('Epoch'); plt.ylabel('Accuracy'); plt.legend(); plt.title('BiLSTM Accuracy')
plt.tight_layout()
plt.savefig('training_curves_bilstm.png', dpi=150)
plt.show()

# 测试集评估
model.eval()
all_preds, all_labels = [], []
with torch.no_grad():
    for x, y in test_loader:
        logits = model(x)
        pred = torch.argmax(logits, dim=1)
        all_preds.extend(pred.cpu().numpy())
        all_labels.extend(y.cpu().numpy())

print("\nBiLSTM 测试集分类报告:")
print(classification_report(all_labels, all_preds, target_names=['Negative', 'Positive']))
cm = confusion_matrix(all_labels, all_preds)
plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Neg','Pos'], yticklabels=['Neg','Pos'])
plt.xlabel('Predicted'); plt.ylabel('True'); plt.title('BiLSTM Confusion Matrix')
plt.savefig('confusion_matrix_bilstm.png', dpi=150)
plt.show()
print("BiLSTM 训练完成，图片已保存。")