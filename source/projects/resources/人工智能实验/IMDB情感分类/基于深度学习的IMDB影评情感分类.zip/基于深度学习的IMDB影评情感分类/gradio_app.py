import os
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

import gradio as gr
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import re
import pickle
from bs4 import BeautifulSoup
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification

# --------------------- 全局设置 ---------------------
device = torch.device('cpu')
MAX_LEN = 200

# 加载共享词表 (由 TextCNN 保存的)
with open('vocab.pkl', 'rb') as f:
    vocab = pickle.load(f)
print(f"词表大小: {len(vocab)}")

# 文本清洗函数
def clean_text(text):
    text = BeautifulSoup(text, "html.parser").get_text()
    text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# 编码函数（CNN/BiLSTM 用）
def encode_ids(text):
    cleaned = clean_text(text)
    ids = [vocab.get(word, vocab['<UNK>']) for word in cleaned.split()]
    if len(ids) > MAX_LEN:
        ids = ids[:MAX_LEN]
    else:
        ids.extend([vocab['<PAD>']] * (MAX_LEN - len(ids)))
    return ids

# --------------------- 模型 1: TextCNN (best_combo) ---------------------
EMBEDDING_DIM = 300
NUM_FILTERS = 100
FILTER_SIZES = [3, 4, 5, 6]
DROPOUT = 0.5

class TextCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Embedding(len(vocab), EMBEDDING_DIM, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv2d(1, NUM_FILTERS, (fs, EMBEDDING_DIM)) for fs in FILTER_SIZES
        ])
        self.fc = nn.Linear(len(FILTER_SIZES) * NUM_FILTERS, 2)
        self.dropout = nn.Dropout(DROPOUT)

    def forward(self, x):
        emb = self.embedding(x).unsqueeze(1)
        conv_out = [F.relu(conv(emb)).squeeze(3) for conv in self.convs]
        pooled = [F.max_pool1d(c, c.size(2)).squeeze(2) for c in conv_out]
        cat = self.dropout(torch.cat(pooled, dim=1))
        return self.fc(cat)

textcnn = TextCNN()
textcnn.load_state_dict(torch.load('textcnn_best.pth', map_location=device))
textcnn.eval()

def predict_textcnn(text):
    ids = encode_ids(text)
    x = torch.LongTensor([ids])
    with torch.no_grad():
        logits = textcnn(x)
        probs = F.softmax(logits, dim=1).cpu().numpy()[0]
    return {'Negative': float(probs[0]), 'Positive': float(probs[1])}

# --------------------- 模型 2: BiLSTM + GloVe ---------------------
# BiLSTM 训练时使用的参数（来自 train_bilstm_glove.py）
BILSTM_EMBEDDING_DIM = 100   # 注意是 100，与 GloVe 6B.100d 一致
HIDDEN_DIM = 128
NUM_LAYERS = 1
LSTM_DROPOUT = 0.5

class BiLSTMGloVe(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Embedding(len(vocab), BILSTM_EMBEDDING_DIM, padding_idx=0)
        self.lstm = nn.LSTM(BILSTM_EMBEDDING_DIM, HIDDEN_DIM, num_layers=NUM_LAYERS,
                            batch_first=True, dropout=0.0, bidirectional=True)  # dropout 设为 0，警告自然消失
        self.dropout = nn.Dropout(LSTM_DROPOUT)
        self.fc = nn.Linear(HIDDEN_DIM * 2, 2)

    def forward(self, x):
        emb = self.embedding(x)
        lstm_out, _ = self.lstm(emb)
        last_out = lstm_out[:, -1, :]
        out = self.dropout(last_out)
        return self.fc(out)

bilstm = BiLSTMGloVe()
bilstm.load_state_dict(torch.load('bilstm_glove.pth', map_location=device))
bilstm.eval()

def predict_bilstm(text):
    ids = encode_ids(text)
    x = torch.LongTensor([ids])
    with torch.no_grad():
        logits = bilstm(x)
        probs = F.softmax(logits, dim=1).cpu().numpy()[0]
    return {'Negative': float(probs[0]), 'Positive': float(probs[1])}

# --------------------- 模型 3: DistilBERT ---------------------
distilbert_path = './results/checkpoint-2500'
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
distilbert = DistilBertForSequenceClassification.from_pretrained(distilbert_path)
distilbert.eval()

def predict_distilbert(text):
    inputs = tokenizer(text, return_tensors='pt', max_length=MAX_LEN,
                       truncation=True, padding='max_length')
    with torch.no_grad():
        logits = distilbert(**inputs).logits
        probs = F.softmax(logits, dim=1).cpu().numpy()[0]
    return {'Negative': float(probs[0]), 'Positive': float(probs[1])}

# --------------------- 综合对比函数 ---------------------
def predict_all(text):
    cnn = predict_textcnn(text)
    lstm = predict_bilstm(text)
    bert = predict_distilbert(text)

    cnn_label = 'Positive' if cnn['Positive'] > cnn['Negative'] else 'Negative'
    lstm_label = 'Positive' if lstm['Positive'] > lstm['Negative'] else 'Negative'
    bert_label = 'Positive' if bert['Positive'] > bert['Negative'] else 'Negative'

    output = f"""
## 🏗️ 三大架构对比预测

| 架构 | 模型 | 预测标签 | 正面概率 | 负面概率 |
|------|------|----------|----------|----------|
| CNN | TextCNN (best_combo) | **{cnn_label}** | {cnn['Positive']:.4f} | {cnn['Negative']:.4f} |
| RNN | BiLSTM + GloVe | **{lstm_label}** | {lstm['Positive']:.4f} | {lstm['Negative']:.4f} |
| Transformer | DistilBERT | **{bert_label}** | {bert['Positive']:.4f} | {bert['Negative']:.4f} |
"""
    return output

# --------------------- 构建 Gradio 界面 ---------------------
with gr.Blocks(title="IMDB 影评情感预测对比系统") as demo:
    gr.Markdown("# 🎬 IMDB 影评情感预测：CNN vs RNN vs Transformer")
    gr.Markdown("输入任意英文影评，比较三种经典深度学习架构的情感分类结果。")

    with gr.Tab("三模型对比"):
        with gr.Row():
            with gr.Column(scale=2):
                input_text = gr.Textbox(
                    lines=5, placeholder="例如：This movie is amazing...",
                    label="📝 输入影评"
                )
                btn = gr.Button("🔍 预测", variant="primary")
            with gr.Column(scale=3):
                output_md = gr.Markdown(label="预测结果")

        btn.click(predict_all, inputs=input_text, outputs=output_md)

    with gr.Tab("TextCNN 预测"):
        gr.Interface(fn=predict_textcnn, inputs=gr.Textbox(lines=3), outputs=gr.Label(num_top_classes=2))

    with gr.Tab("BiLSTM+GloVe 预测"):
        gr.Interface(fn=predict_bilstm, inputs=gr.Textbox(lines=3), outputs=gr.Label(num_top_classes=2))

    with gr.Tab("DistilBERT 预测"):
        gr.Interface(fn=predict_distilbert, inputs=gr.Textbox(lines=3), outputs=gr.Label(num_top_classes=2))

    gr.Examples(
        examples=[
            ["This movie was absolutely fantastic! I loved every moment."],
            ["A complete waste of time, terrible acting and boring plot."],
            ["The film had great cinematography but the story was too slow and predictable."]
        ],
        inputs=input_text
    )
if __name__ == '__main__':
    demo.launch()

#if __name__ == '__main__':
#    demo.launch(server_name="0.0.0.0")  #局域网访问
#ipconfig
