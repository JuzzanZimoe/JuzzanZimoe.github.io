import argparse
import pandas as pd
import numpy as np
import re
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
from collections import Counter
from bs4 import BeautifulSoup
from tqdm import tqdm
from torch.utils.data import Dataset, DataLoader
import os
import time
import json

# ================== 1. 命令行参数解析 ==================
parser = argparse.ArgumentParser(description='TextCNN 超参数实验')
parser.add_argument('--exp_name', type=str, required=True, help='实验名称，例如 A1_embed50')
parser.add_argument('--embedding_dim', type=int, default=100, help='词向量维度')
parser.add_argument('--num_filters', type=int, default=100, help='卷积核数量')
parser.add_argument('--filter_sizes', type=str, default='3,4,5', help='卷积核大小组合，逗号分隔，如 3,4,5')
parser.add_argument('--lr', type=float, default=0.001, help='学习率')
parser.add_argument('--dropout', type=float, default=0.5, help='Dropout 比例')
parser.add_argument('--batch_size', type=int, default=64, help='批次大小')
parser.add_argument('--max_len', type=int, default=200, help='序列最大长度')
parser.add_argument('--epochs', type=int, default=5, help='训练轮数')
args = parser.parse_args()

# 转化 filter_sizes 为列表
filter_sizes_list = [int(x) for x in args.filter_sizes.split(',')]

DEVICE = torch.device('cpu')

# ================== 2. 数据预处理（与之前完全一致） ==================
TRAIN_PATH = "question2_train.csv"
TEST_PATH  = "question2_test.csv"

def clean_text(text):
    text = BeautifulSoup(text, "html.parser").get_text()
    text = re.sub(r'[^a-zA-Z\s]', '', text).lower()
    text = re.sub(r'\s+', ' ', text).strip()
    return text

print("加载数据...")
train_df = pd.read_csv(TRAIN_PATH)
test_df  = pd.read_csv(TEST_PATH)

tqdm.pandas(desc="清洗训练集")
train_df['clean'] = train_df['text'].progress_apply(clean_text)
tqdm.pandas(desc="清洗测试集")
test_df['clean'] = test_df['text'].progress_apply(clean_text)

word_counter = Counter()
for text in tqdm(train_df['clean'], desc="统计词频"):
    word_counter.update(text.split())

vocab = {'<PAD>': 0, '<UNK>': 1}
MIN_WORD_FREQ = 5
for word, freq in word_counter.items():
    if freq >= MIN_WORD_FREQ:
        vocab[word] = len(vocab)
vocab_size = len(vocab)

def encode(text, vocab, max_len):
    ids = [vocab.get(word, vocab['<UNK>']) for word in text.split()]
    if len(ids) > max_len:
        ids = ids[:max_len]
    else:
        ids.extend([vocab['<PAD>']] * (max_len - len(ids)))
    return ids

tqdm.pandas(desc="编码训练集")
train_df['ids'] = train_df['clean'].progress_apply(lambda x: encode(x, vocab, args.max_len))
tqdm.pandas(desc="编码测试集")
test_df['ids'] = test_df['clean'].progress_apply(lambda x: encode(x, vocab, args.max_len))

X_train_all = np.array(train_df['ids'].tolist(), dtype=np.int64)
y_train_all = train_df['label'].values.astype(np.int64)
X_test = np.array(test_df['ids'].tolist(), dtype=np.int64)
y_test = test_df['label'].values.astype(np.int64)

X_train, X_val, y_train, y_val = train_test_split(
    X_train_all, y_train_all, test_size=0.2, random_state=42, stratify=y_train_all
)

class IMDBDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.LongTensor(X)
        self.y = torch.LongTensor(y)
    def __len__(self): return len(self.y)
    def __getitem__(self, idx): return self.X[idx], self.y[idx]

train_loader = DataLoader(IMDBDataset(X_train, y_train), batch_size=args.batch_size, shuffle=True)
val_loader = DataLoader(IMDBDataset(X_val, y_val), batch_size=args.batch_size, shuffle=False)
test_loader = DataLoader(IMDBDataset(X_test, y_test), batch_size=args.batch_size, shuffle=False)

# ================== 3. TextCNN 模型 ==================
class TextCNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim, num_filters, filter_sizes, dropout, num_classes=2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv2d(1, num_filters, (fs, embedding_dim)) for fs in filter_sizes
        ])
        self.fc = nn.Linear(len(filter_sizes) * num_filters, num_classes)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        emb = self.embedding(x).unsqueeze(1)
        conv_out = [F.relu(conv(emb)).squeeze(3) for conv in self.convs]
        pooled = [F.max_pool1d(c, c.size(2)).squeeze(2) for c in conv_out]
        cat = self.dropout(torch.cat(pooled, dim=1))
        logits = self.fc(cat)
        return logits

model = TextCNN(vocab_size, args.embedding_dim, args.num_filters,
                filter_sizes_list, args.dropout).to(DEVICE)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

# ================== 4. 训练与评估 ==================
def train_epoch():
    model.train()
    total_loss, correct, total = 0, 0, 0
    for x, y in train_loader:
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        pred = torch.argmax(logits, dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return total_loss / len(train_loader), correct / total

def eval_epoch(loader):
    model.eval()
    total_loss, correct, total = 0, 0, 0
    with torch.no_grad():
        for x, y in loader:
            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item()
            pred = torch.argmax(logits, dim=1)
            correct += (pred == y).sum().item()
            total += y.size(0)
    return total_loss / len(loader), correct / total

train_losses, val_losses = [], []
train_accs, val_accs = [], []

print(f"\n开始实验: {args.exp_name}")
t_start = time.time()
for epoch in range(1, args.epochs+1):
    tr_loss, tr_acc = train_epoch()
    vl_loss, vl_acc = eval_epoch(val_loader)
    train_losses.append(tr_loss)
    val_losses.append(vl_loss)
    train_accs.append(tr_acc)
    val_accs.append(vl_acc)
    print(f"Epoch {epoch}/{args.epochs} | Train Loss: {tr_loss:.4f} Acc: {tr_acc:.4f} | Val Loss: {vl_loss:.4f} Acc: {vl_acc:.4f}")
t_train = time.time() - t_start

# 最佳验证准确率
best_val_acc = max(val_accs)

# 测试集最终评估
model.eval()
all_preds, all_labels = [], []
with torch.no_grad():
    for x, y in test_loader:
        logits = model(x)
        pred = torch.argmax(logits, dim=1)
        all_preds.extend(pred.cpu().numpy())
        all_labels.extend(y.cpu().numpy())

report = classification_report(all_labels, all_preds, target_names=['Negative','Positive'], output_dict=True)
test_acc = report['accuracy']

# 打印报告
print(f"\n{args.exp_name} 测试集准确率: {test_acc:.4f}")
print(classification_report(all_labels, all_preds, target_names=['Negative','Positive']))

# ================== 5. 结果记录 ==================
result = {
    'exp_name': args.exp_name,
    'embedding_dim': args.embedding_dim,
    'num_filters': args.num_filters,
    'filter_sizes': args.filter_sizes,
    'lr': args.lr,
    'dropout': args.dropout,
    'batch_size': args.batch_size,
    'max_len': args.max_len,
    'epochs': args.epochs,
    'best_val_acc': best_val_acc,
    'test_acc': test_acc,
    'train_time_sec': t_train,
    'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
}

# 写入 CSV 总结文件（自动追加）
csv_file = 'experiment_results.csv'
if not os.path.exists(csv_file):
    pd.DataFrame([result]).to_csv(csv_file, index=False)
else:
    pd.DataFrame([result]).to_csv(csv_file, mode='a', header=False, index=False)

print(f"\n✅ 实验结果已写入 {csv_file}")

# ================== 6. 保存训练曲线（可选，避免覆盖，按实验名命名） ==================
plt.figure(figsize=(12,4))
plt.subplot(1,2,1)
plt.plot(range(1, args.epochs+1), train_losses, label='Train Loss')
plt.plot(range(1, args.epochs+1), val_losses, label='Val Loss')
plt.xlabel('Epoch'); plt.ylabel('Loss'); plt.legend()
plt.title(f'Loss Curve - {args.exp_name}')
plt.subplot(1,2,2)
plt.plot(range(1, args.epochs+1), train_accs, label='Train Acc')
plt.plot(range(1, args.epochs+1), val_accs, label='Val Acc')
plt.xlabel('Epoch'); plt.ylabel('Accuracy'); plt.legend()
plt.title(f'Accuracy Curve - {args.exp_name}')
plt.tight_layout()
plt.savefig(f'curve_{args.exp_name}.png', dpi=150)
plt.close()

# 混淆矩阵
cm = confusion_matrix(all_labels, all_preds)
plt.figure(figsize=(5,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Neg','Pos'], yticklabels=['Neg','Pos'])
plt.xlabel('Predicted'); plt.ylabel('True')
plt.title(f'Confusion Matrix - {args.exp_name}')
plt.savefig(f'cm_{args.exp_name}.png', dpi=150)
plt.close()

print(f"曲线图已保存为 curve_{args.exp_name}.png，混淆矩阵已保存为 cm_{args.exp_name}.png")

# ================== 保存模型和词表，用于 Gradio 界面 ==================
import pickle

# 保存模型参数
torch.save(model.state_dict(), 'textcnn_best.pth')
print("✅ 模型参数已保存为 textcnn_best.pth")

# 保存词表
with open('vocab.pkl', 'wb') as f:
    pickle.dump(vocab, f)
print("✅ 词表已保存为 vocab.pkl")