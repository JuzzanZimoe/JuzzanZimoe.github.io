import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from preprocess import X_train, y_train, X_val, y_val, X_test, y_test, MAX_LEN, vocab  # 从之前的脚本导入关键变量
from torch.utils.data import Dataset, DataLoader

# ======================== 1. 定义 Dataset（复用之前的） ========================
class IMDBDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.LongTensor(X)
        self.y = torch.LongTensor(y)
    def __len__(self):
        return len(self.y)
    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ======================== 2. 定义 TextCNN 模型 ========================
class TextCNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim=100, num_filters=100, filter_sizes=[3,4,5], dropout=0.5, num_classes=2):
        super(TextCNN, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv2d(in_channels=1, out_channels=num_filters, kernel_size=(fs, embedding_dim))
            for fs in filter_sizes
        ])
        self.fc = nn.Linear(len(filter_sizes) * num_filters, num_classes)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # x: (batch, seq_len)
        emb = self.embedding(x).unsqueeze(1)  # (batch, 1, seq_len, embed_dim)
        conv_out = [F.relu(conv(emb)).squeeze(3) for conv in self.convs]  # each (batch, num_filters, seq_len - fs + 1)
        pooled = [F.max_pool1d(c, c.size(2)).squeeze(2) for c in conv_out]  # each (batch, num_filters)
        cat = self.dropout(torch.cat(pooled, dim=1))  # (batch, num_filters * len(filter_sizes))
        logits = self.fc(cat)
        return logits

# ======================== 3. 训练函数 ========================
def train_one_epoch(model, loader, optimizer, criterion):
    model.train()
    total_loss = 0
    correct = 0
    total = 0
    for x, y in loader:
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        pred = torch.argmax(logits, dim=1)
        correct += (pred == y).sum().item()
        total += y.size(0)
    return total_loss / len(loader), correct / total

def eval_one_epoch(model, loader, criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for x, y in loader:
            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item()
            pred = torch.argmax(logits, dim=1)
            correct += (pred == y).sum().item()
            total += y.size(0)
    return total_loss / len(loader), correct / total

# ======================== 4. 正式训练 ========================
DEVICE = torch.device('cpu')  # 你的 CPU
BATCH_SIZE = 64
EPOCHS = 5
LR = 0.001

# 构建 DataLoader（这里的 X_train, X_val 等是从 preprocess 导出的）
train_dataset = IMDBDataset(X_train, y_train)
val_dataset = IMDBDataset(X_val, y_val)
test_dataset = IMDBDataset(X_test, y_test)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

# 初始化模型
vocab_size = len(vocab)
model = TextCNN(vocab_size, embedding_dim=100, num_filters=100, filter_sizes=[3,4,5], dropout=0.5)
model.to(DEVICE)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LR)

# 记录曲线数据
train_losses, val_losses = [], []
train_accs, val_accs = [], []

print("开始训练 TextCNN...")
for epoch in range(1, EPOCHS+1):
    train_loss, train_acc = train_one_epoch(model, train_loader, optimizer, criterion)
    val_loss, val_acc = eval_one_epoch(model, val_loader, criterion)

    train_losses.append(train_loss)
    val_losses.append(val_loss)
    train_accs.append(train_acc)
    val_accs.append(val_acc)

    print(f"Epoch {epoch}/{EPOCHS} | Train Loss: {train_loss:.4f} Acc: {train_acc:.4f} | Val Loss: {val_loss:.4f} Acc: {val_acc:.4f}")

print("训练完成！")

# ======================== 5. 绘制训练曲线 ========================
plt.figure(figsize=(12,4))
plt.subplot(1,2,1)
plt.plot(range(1, EPOCHS+1), train_losses, label='Train Loss')
plt.plot(range(1, EPOCHS+1), val_losses, label='Val Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.title('Loss Curve')

plt.subplot(1,2,2)
plt.plot(range(1, EPOCHS+1), train_accs, label='Train Acc')
plt.plot(range(1, EPOCHS+1), val_accs, label='Val Acc')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.title('Accuracy Curve')

plt.tight_layout()
plt.savefig('training_curves.png', dpi=150)
plt.show()
print("曲线已保存为 training_curves.png")

# ======================== 6. 测试集评估（最终用 test_loader） ========================
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

model.eval()
all_preds, all_labels = [], []
with torch.no_grad():
    for x, y in test_loader:
        logits = model(x)
        pred = torch.argmax(logits, dim=1)
        all_preds.extend(pred.cpu().numpy())
        all_labels.extend(y.cpu().numpy())

print("\n测试集分类报告:")
print(classification_report(all_labels, all_preds, target_names=['Negative', 'Positive']))

# 混淆矩阵
cm = confusion_matrix(all_labels, all_preds)
plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Neg','Pos'], yticklabels=['Neg','Pos'])
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.savefig('confusion_matrix.png', dpi=150)
plt.show()
print("混淆矩阵已保存为 confusion_matrix.png")