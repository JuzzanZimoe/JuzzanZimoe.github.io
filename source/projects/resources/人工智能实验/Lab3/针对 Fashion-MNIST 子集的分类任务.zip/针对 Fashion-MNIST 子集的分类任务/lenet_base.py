import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from tqdm import tqdm

# ==========================================
# 1. 自定义数据集 (同 baseline lenet.py)
#    负责从 CSV 和 images/ 加载图片，转为 Tensor
# ==========================================
class FashionDataset(Dataset):
    def __init__(self, data_dir, transform=None):
        import pandas as pd
        self.data_dir = data_dir
        self.transform = transform
        csv_path = os.path.join(data_dir, 'labels.csv')
        self.df = pd.read_csv(csv_path)
        self.img_dir = os.path.join(data_dir, 'images')

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        img_name = self.df.iloc[idx]['filename']
        label = self.df.iloc[idx]['label_id']
        img_path = os.path.join(self.img_dir, img_name)
        image = Image.open(img_path).convert('L')           # 灰度单通道
        if self.transform:
            image = self.transform(image)
        return image, label

# ==========================================
# 2. LeNet-5 模型定义 (同 baseline，未修改)
#    两层卷积 + 三层全连接
# ==========================================
class LeNet5(nn.Module):
    def __init__(self, num_classes=10):
        super(LeNet5, self).__init__()
        # 卷积层 1：输入 1 通道，输出 6 通道，5x5 核，不做填充，输出 24x24
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5)
        # 卷积层 2：输入 6 通道，输出 16 通道，5x5 核，输出 8x8（经过池化后是 12x12 -> 8x8）
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)
        # 全连接层：特征图展平后 16*4*4 = 256
        self.fc1 = nn.Linear(16*4*4, 120)                   # 256 -> 120
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, num_classes)                # 输出 10 类（数据集仅 5 类也不影响）

    def forward(self, x):
        # 卷积 + ReLU + 2x2 最大池化
        x = F.max_pool2d(F.relu(self.conv1(x)), 2)          # 1*28*28 -> 6*24*24 -> 6*12*12
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)          # 6*12*12 -> 16*8*8 -> 16*4*4
        x = x.view(x.size(0), -1)                          # 展平为一维
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)                                    # 输出层不加激活（CrossEntropyLoss 自带 softmax）
        return x

# ==========================================
# 3. 训练函数 (修改：记录每个 epoch 的 loss、训练准确率和测试准确率)
#    用于后续绘制曲线
# ==========================================
def train_model(model, train_loader, test_loader, device, epochs, optimizer, criterion):
    train_losses = []
    train_accs = []
    test_accs = []

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        correct_train = 0
        total_train = 0

        loop = tqdm(train_loader, desc=f'Epoch {epoch+1}/{epochs}')
        for images, labels in loop:
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            correct_train += (predicted == labels).sum().item()
            total_train += labels.size(0)

            loop.set_postfix(loss=loss.item())

        avg_loss = running_loss / len(train_loader)           # 平均训练损失
        train_acc = 100 * correct_train / total_train         # 训练准确率

        # 在测试集上评估
        model.eval()
        correct_test = 0
        total_test = 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                _, predicted = torch.max(outputs, 1)
                correct_test += (predicted == labels).sum().item()
                total_test += labels.size(0)
        test_acc = 100 * correct_test / total_test

        # 保存历史数据
        train_losses.append(avg_loss)
        train_accs.append(train_acc)
        test_accs.append(test_acc)

        print(f'Epoch {epoch+1:2d} | Loss: {avg_loss:.4f} | Train Acc: {train_acc:.2f}% | Test Acc: {test_acc:.2f}%')

    return train_losses, train_accs, test_accs

# ==========================================
# 4. ★ 新增可视化函数
#    (1) plot_curves ：绘制损失和准确率曲线
#    (2) visualize_feature_maps ：提取并保存卷积层特征图
# ==========================================

def plot_curves(train_losses, train_accs, test_accs, save_path='curves.png'):
    """绘制训练损失、训练准确率、测试准确率随 epoch 的变化曲线"""
    epochs = range(1, len(train_losses)+1)
    plt.figure(figsize=(12, 4))

    # 左图：损失曲线
    plt.subplot(1, 2, 1)
    plt.plot(epochs, train_losses, 'b-o', label='Training Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title('Training Loss Curve')
    plt.grid(True)

    # 右图：准确率对比曲线
    plt.subplot(1, 2, 2)
    plt.plot(epochs, train_accs, 'g-o', label='Train Accuracy')
    plt.plot(epochs, test_accs, 'r-o', label='Test Accuracy')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy (%)')
    plt.title('Accuracy Curves')
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.show()
    print(f"曲线图已保存至 {save_path}")

def visualize_feature_maps(model, image_tensor, device):
    """
    提取并显示 conv1 和 conv2 的特征图
    image_tensor: 形状 (1, 1, 28, 28) 的单张图片张量
    """
    model.eval()
    image_tensor = image_tensor.to(device)

    activations = {}
    # hook 函数：在指定层前向传播后保存输出
    def get_activation(name):
        def hook(model, input, output):
            activations[name] = output.detach().cpu()
        return hook

    # 注册前向钩子到 conv1 和 conv2 层
    model.conv1.register_forward_hook(get_activation('conv1'))
    model.conv2.register_forward_hook(get_activation('conv2'))

    with torch.no_grad():
        _ = model(image_tensor)   # 触发前向传播，钩子自动保存中间输出

    # conv1 特征图: (1, 6, 24, 24) -> 去掉 batch 维度，得到 (6, 24, 24)
    conv1_feat = activations['conv1'].squeeze(0)
    fig1, axes1 = plt.subplots(2, 3, figsize=(9, 6))
    fig1.suptitle('Conv1 Feature Maps (6 channels)', fontsize=14)
    for idx, ax in enumerate(axes1.flat):
        ax.imshow(conv1_feat[idx].numpy(), cmap='gray')
        ax.axis('off')
    plt.tight_layout()
    plt.savefig('conv1_feature_maps.png', dpi=150, bbox_inches='tight')
    plt.close(fig1)   # 关闭 figure，释放内存

    # conv2 特征图: (1, 16, 8, 8)
    conv2_feat = activations['conv2'].squeeze(0)
    fig2, axes2 = plt.subplots(4, 4, figsize=(8, 8))
    fig2.suptitle('Conv2 Feature Maps (16 channels)', fontsize=14)
    for idx, ax in enumerate(axes2.flat):
        ax.imshow(conv2_feat[idx].numpy(), cmap='gray')
        ax.axis('off')
    plt.tight_layout()
    plt.savefig('conv2_feature_maps.png', dpi=150, bbox_inches='tight')
    plt.close(fig2)

    print("特征图已保存为 conv1_feature_maps.png 和 conv2_feature_maps.png")

# ==========================================
# 5. 参数解析 (默认值已设为经调优的最佳超参数，而非 baseline 默认)
#    可根据需要修改，此处使用 SGD, lr=0.01, momentum=0.5, epochs=15
# ==========================================
def get_args_parser():
    parser = argparse.ArgumentParser(description='LeNet-5 可视化实验 - 最佳超参数')
    parser.add_argument('--train_dir', type=str, default='./data/train')
    parser.add_argument('--test_dir', type=str, default='./data/test')
    parser.add_argument('--batch_size', type=int, default=16, help='批次大小')
    parser.add_argument('--lr', type=float, default=0.01, help='学习率')
    parser.add_argument('--epochs', type=int, default=15, help='训练轮数')
    parser.add_argument('--optimizer', type=str, default='sgd', choices=['adam', 'sgd', 'rmsprop'])
    parser.add_argument('--momentum', type=float, default=0.5, help='动量（仅SGD有效）')
    parser.add_argument('--random_state', type=int, default=42, help='随机种子')
    return parser

# ==========================================
# 6. 主程序
# ==========================================
if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args()

    # 固定随机种子，保证结果可复现
    torch.manual_seed(args.random_state)
    np.random.seed(args.random_state)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"使用设备: {device}")
    print(f"超参数: lr={args.lr}, batch_size={args.batch_size}, epochs={args.epochs}, optimizer={args.optimizer}, momentum={args.momentum}")

    # 数据预处理：转换为 Tensor（像素值自动归一化到 [0,1]）
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])

    train_dataset = FashionDataset(args.train_dir, transform=transform)
    test_dataset = FashionDataset(args.test_dir, transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    print(f"训练集样本数: {len(train_dataset)}")
    print(f"测试集样本数: {len(test_dataset)}")

    # 初始化模型、损失函数、优化器
    model = LeNet5(num_classes=10).to(device)
    criterion = nn.CrossEntropyLoss()

    # 根据命令行参数选择优化器
    if args.optimizer == 'adam':
        optimizer = optim.Adam(model.parameters(), lr=args.lr)
    elif args.optimizer == 'sgd':
        optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)
    elif args.optimizer == 'rmsprop':
        optimizer = optim.RMSprop(model.parameters(), lr=args.lr)

    # 训练
    print("\n开始训练...")
    train_losses, train_accs, test_accs = train_model(
        model, train_loader, test_loader, device, args.epochs, optimizer, criterion
    )

    # 最终准确率
    final_test_acc = test_accs[-1]
    print(f"\n训练完成！最终测试集准确率: {final_test_acc:.2f}%")

    # ★ 绘制并保存曲线
    plot_curves(train_losses, train_accs, test_accs)

    # ★ 可视化特征图：取测试集的第一张图片
    sample_img, sample_label = next(iter(test_loader))   # 获取一个 batch
    sample_img = sample_img[0:1]   # 取 batch 中的第一张，保持维度 (1,1,28,28)
    print(f"\n可视化测试样本，标签: {sample_label[0].item()}")
    visualize_feature_maps(model, sample_img, device)

    print("\n程序运行结束，请查看生成的图片文件。")