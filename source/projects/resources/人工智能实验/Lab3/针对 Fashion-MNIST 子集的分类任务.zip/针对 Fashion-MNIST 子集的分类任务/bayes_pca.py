import os
import argparse
import pandas as pd
import numpy as np
from PIL import Image

from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA                    # ★ 导入 PCA
from sklearn.preprocessing import StandardScaler         # ★ 导入标准化

# ==========================================
# 1. 数据集加载函数（同 baseline）
#    读取图片并展平为 784 维特征
# ==========================================
def load_data(data_dir):
    csv_file = os.path.join(data_dir, 'labels.csv')
    img_dir = os.path.join(data_dir, 'images')
    df = pd.read_csv(csv_file)

    X = []
    y = []
    for idx, row in df.iterrows():
        img_name = row['filename']
        label = row['label_id']
        img_path = os.path.join(img_dir, img_name)
        image = Image.open(img_path).convert('L')
        img_flat = np.array(image).flatten()
        X.append(img_flat)
        y.append(label)
    return np.array(X), np.array(y)

# ==========================================
# 2. 参数解析器（新增 --pca_components 参数）
#    用于指定降维后的维度
# ==========================================
def get_args_parser():
    parser = argparse.ArgumentParser(description='高斯朴素贝叶斯 + PCA 降维 - FashionMNIST子集')
    parser.add_argument('--train_dir', type=str, default='./data/train', help='训练集路径')
    parser.add_argument('--test_dir', type=str, default='./data/test', help='测试集路径')
    parser.add_argument('--random_state', type=int, default=42, help='随机种子')
    # ★ 新增：PCA 目标维度
    parser.add_argument('--pca_components', type=int, default=50,
                        help='PCA 降维后的特征数（如 10, 20, 50, 100, 200 等）')
    return parser

# 类别映射（同 baseline）
LABEL_NAME_MAP = {
    0: "T-shirt/top",
    3: "Dress",
    5: "Sandal",
    6: "Shirt",
    7: "Sneaker"
}
TARGET_CLASSES = [0, 3, 5, 6, 7]

# ==========================================
# 3. 主程序
# ==========================================
if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args()

    print("🚀 启动 高斯朴素贝叶斯 + PCA 降维 训练")
    print(f"📂 训练集路径: {args.train_dir}")
    print(f"📂 测试集路径: {args.test_dir}")
    print(f"🔢 PCA 目标维度: {args.pca_components}")

    # 加载原始数据（784 维像素）
    X_train_raw, y_train = load_data(args.train_dir)
    X_test_raw, y_test = load_data(args.test_dir)

    print(f"📊 训练集: {len(X_train_raw)} 张 | 测试集: {len(X_test_raw)} 张")
    print(f"📏 原始特征维度: {X_train_raw.shape[1]}")

    # --------------------------
    # ★ 改进核心：PCA 降维流程
    # --------------------------
    # 步骤 1：标准化（每个特征均值 0 方差 1），PCA 对尺度敏感，必须做
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_raw)
    X_test_scaled = scaler.transform(X_test_raw)        # 测试集用训练集的均值和标准差

    # 步骤 2：PCA 降维
    #   n_components 即目标维度数
    pca = PCA(n_components=args.pca_components, random_state=args.random_state)
    X_train_pca = pca.fit_transform(X_train_scaled)     # 在训练集上“学习”变换矩阵并降维
    X_test_pca = pca.transform(X_test_scaled)           # 测试集应用同一个变换矩阵

    # 查看保留了原始数据多少方差信息
    explained_variance_ratio = pca.explained_variance_ratio_
    total_variance_retained = np.sum(explained_variance_ratio) * 100

    print(f"📏 降维后特征维度: {X_train_pca.shape[1]}")
    print(f"📈 保留了原始数据 {total_variance_retained:.2f}% 的方差信息")

    # --------------------------
    # 高斯朴素贝叶斯（使用降维后的特征训练，同 baseline）
    # --------------------------
    model = GaussianNB()
    model.fit(X_train_pca, y_train)          # 注意：这里用降维后的特征训练

    # 预测
    y_pred = model.predict(X_test_pca)
    overall_acc = accuracy_score(y_test, y_pred) * 100

    # 统计每个类别的准确率
    class_correct = {c: 0 for c in TARGET_CLASSES}
    class_total = {c: 0 for c in TARGET_CLASSES}

    for true, pred in zip(y_test, y_pred):
        if true in TARGET_CLASSES:
            class_total[true] += 1
            if true == pred:
                class_correct[true] += 1

    # --------------------------
    # 打印结果
    # --------------------------
    print("\n" + "="*50)
    print(f"🎯 高斯朴素贝叶斯 + PCA({args.pca_components}维) 测试结果")
    print("="*50)
    print(f"✅ 总体测试准确率: {overall_acc:.2f}%")
    print("\n📊 各类别正确率：")
    for c in TARGET_CLASSES:
        acc = 100 * class_correct[c] / class_total[c] if class_total[c] != 0 else 0
        print(f"   类别{c:2d} ({LABEL_NAME_MAP[c]:10s}): {class_correct[c]}/{class_total[c]} | 准确率={acc:.2f}%")

    print("\n🎉 运行完成！")