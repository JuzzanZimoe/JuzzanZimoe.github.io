import os
import argparse
import pandas as pd
import numpy as np
from PIL import Image

from sklearn.naive_bayes import BernoulliNB          # 改用伯努利朴素贝叶斯
from sklearn.metrics import accuracy_score

# ==========================================
# 1. 数据集加载函数（同 bayes.py baseline）
#    作用：读取 labels.csv 和 images/，将每张 28×28 灰度图展平为 784 维向量
# ==========================================
def load_data(data_dir):
    csv_file = os.path.join(data_dir, 'labels.csv')
    img_dir = os.path.join(data_dir, 'images')
    df = pd.read_csv(csv_file)

    X = []
    y = []
    for idx, row in df.iterrows():
        img_name = row['filename']
        label = row['label_id']
        img_path = os.path.join(img_dir, img_name)
        image = Image.open(img_path).convert('L')      # 转为灰度图
        img_flat = np.array(image).flatten()            # 二维 -> 一维 784
        X.append(img_flat)
        y.append(label)
    return np.array(X), np.array(y)

# ==========================================
# 2. 参数解析器（改进点：新增二值化阈值参数）
#    此阈值用于将像素值转换为 0/1 二元特征
# ==========================================
def get_args_parser():
    parser = argparse.ArgumentParser(description='伯努利朴素贝叶斯 - FashionMNIST子集')
    parser.add_argument('--train_dir', type=str, default='./data/train', help='训练集路径')
    parser.add_argument('--test_dir', type=str, default='./data/test', help='测试集路径')
    parser.add_argument('--random_state', type=int, default=42, help='随机种子')
    # ★ 新增参数：二值化阈值，默认 128
    parser.add_argument('--binarize_threshold', type=float, default=128.0,
                        help='将像素值大于此阈值的设为1，否则为0（默认128）')
    return parser

# 类别映射（同 baseline）
LABEL_NAME_MAP = {
    0: "T-shirt/top",
    3: "Dress",
    5: "Sandal",
    6: "Shirt",
    7: "Sneaker"
}
TARGET_CLASSES = [0, 3, 5, 6, 7]

# ==========================================
# 3. 主程序
# ==========================================
if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args()

    print("🚀 启动 伯努利朴素贝叶斯 训练")
    print(f"📂 训练集路径: {args.train_dir}")
    print(f"📂 测试集路径: {args.test_dir}")
    print(f"⚙️  二值化阈值: {args.binarize_threshold}")

    # 加载数据（原始像素值 0~255）
    X_train_raw, y_train = load_data(args.train_dir)
    X_test_raw, y_test = load_data(args.test_dir)

    print(f"📊 训练集: {len(X_train_raw)} 张 | 测试集: {len(X_test_raw)} 张")
    print(f"📏 原始特征维度: {X_train_raw.shape[1]}")

    # --------------------------
    # ★ 改进核心：二值化处理
    #   将灰度像素值按照阈值转换为 0 或 1，用于伯努利朴素贝叶斯
    # --------------------------
    # 例如 threshold=128 → 像素>128 变成1，像素≤128 变成0
    X_train_bin = (X_train_raw > args.binarize_threshold).astype(np.uint8)
    X_test_bin  = (X_test_raw > args.binarize_threshold).astype(np.uint8)

    # 查看二值化后 1 的比例，辅助分析模型表现
    ones_ratio_train = np.mean(X_train_bin) * 100
    ones_ratio_test  = np.mean(X_test_bin) * 100
    print(f"🔲 训练集 1 的比例: {ones_ratio_train:.2f}%")
    print(f"🔲 测试集 1 的比例: {ones_ratio_test:.2f}%")

    # --------------------------
    # ★ 改进核心：替换为伯努利朴素贝叶斯
    #   BernoulliNB 假设特征为二值（0/1），适用于图像二值化后的情形
    # --------------------------
    # 创建模型：alpha 是拉普拉斯平滑参数，默认 1.0
    model = BernoulliNB(alpha=1.0)
    # 用 0/1 二值特征训练
    model.fit(X_train_bin, y_train)

    # 预测（baseline 部分相同）
    y_pred = model.predict(X_test_bin)
    overall_acc = accuracy_score(y_test, y_pred) * 100

    # 统计每个类别的准确率（同 baseline）
    class_correct = {c: 0 for c in TARGET_CLASSES}
    class_total = {c: 0 for c in TARGET_CLASSES}

    for true, pred in zip(y_test, y_pred):
        if true in TARGET_CLASSES:
            class_total[true] += 1
            if true == pred:
                class_correct[true] += 1

    # --------------------------
    # 打印结果（同 baseline）
    # --------------------------
    print("\n" + "="*50)
    print(f"🎯 伯努利朴素贝叶斯 (阈值={args.binarize_threshold}) 测试结果")
    print("="*50)
    print(f"✅ 总体测试准确率: {overall_acc:.2f}%")
    print("\n📊 各类别正确率：")
    for c in TARGET_CLASSES:
        acc = 100 * class_correct[c] / class_total[c] if class_total[c] != 0 else 0
        print(f"   类别{c:2d} ({LABEL_NAME_MAP[c]:10s}): {class_correct[c]}/{class_total[c]} | 准确率={acc:.2f}%")

    print("\n🎉 运行完成！")