import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from tqdm import tqdm

# ------------------------------------------------------------
# 1. 数据集加载（同 baseline）
# ------------------------------------------------------------
class FashionDataset(Dataset):
    def __init__(self, data_dir, transform=None):
        import pandas as pd
        self.data_dir = data_dir
        self.transform = transform
        csv_path = os.path.join(data_dir, 'labels.csv')
        self.df = pd.read_csv(csv_path)
        self.img_dir = os.path.join(data_dir, 'images')

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        img_name = self.df.iloc[idx]['filename']
        label = self.df.iloc[idx]['label_id']
        img_path = os.path.join(self.img_dir, img_name)
        image = Image.open(img_path).convert('L')
        if self.transform:
            image = self.transform(image)
        return image, label

# ------------------------------------------------------------
# 2. ★ 改进的 LeNet-5 模型
#    增加可选的 Dropout 层，仅加在第一个全连接层之后
# ------------------------------------------------------------
class LeNet5_Plus(nn.Module):
    def __init__(self, num_classes=10, dropout=False):
        super(LeNet5_Plus, self).__init__()
        self.dropout = dropout
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5)           # 同 baseline
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)
        self.fc1 = nn.Linear(16 * 4 * 4, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, num_classes)

        # ★ 根据参数决定是否添加 Dropout 层（丢弃概率 0.25）
        if self.dropout:
            self.dropout_layer = nn.Dropout(p=0.25)
        else:
            self.dropout_layer = nn.Identity()   # 不做任何操作

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), 2)
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.dropout_layer(x)               # ★ 在 fc1 的激活后应用 Dropout（训练时生效，eval 时关闭）
        x = F.relu(self.fc2(x))
        # 注意：未在 fc2 后加 Dropout，避免过强的正则化导致欠拟合
        x = self.fc3(x)
        return x

# ------------------------------------------------------------
# 3. 训练函数（支持 scheduler，用于学习率衰减）
# ------------------------------------------------------------
def train_model(model, train_loader, test_loader, device, epochs, optimizer, criterion, scheduler=None):
    train_losses = []
    train_accs = []
    test_accs = []

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        correct_train = 0
        total_train = 0

        loop = tqdm(train_loader, desc=f'Epoch {epoch+1}/{epochs}')
        for images, labels in loop:
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            correct_train += (predicted == labels).sum().item()
            total_train += labels.size(0)

            loop.set_postfix(loss=loss.item())

        avg_loss = running_loss / len(train_loader)
        train_acc = 100 * correct_train / total_train

        # 测试阶段
        model.eval()
        correct_test = 0
        total_test = 0
        with torch.no_grad():
            for images, labels in test_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                _, predicted = torch.max(outputs, 1)
                correct_test += (predicted == labels).sum().item()
                total_test += labels.size(0)
        test_acc = 100 * correct_test / total_test

        train_losses.append(avg_loss)
        train_accs.append(train_acc)
        test_accs.append(test_acc)

        print(f'Epoch {epoch+1:2d} | Loss: {avg_loss:.4f} | Train Acc: {train_acc:.2f}% | Test Acc: {test_acc:.2f}%')

        # ★ 如果设置了学习率调度器，则在每个 epoch 后更新学习率
        if scheduler:
            scheduler.step()

    return train_losses, train_accs, test_accs

# ------------------------------------------------------------
# 4. 参数解析（新增三个改进开关）
# ------------------------------------------------------------
def get_args_parser():
    parser = argparse.ArgumentParser(description='LeNet-5 改进实验 (消融控制)')
    parser.add_argument('--train_dir', type=str, default='./data/train')
    parser.add_argument('--test_dir', type=str, default='./data/test')
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epochs', type=int, default=25,    # 默认 25 轮，充分训练
                        help='训练轮数（推荐 25~30 用于组合实验）')
    parser.add_argument('--optimizer', type=str, default='sgd', choices=['adam', 'sgd', 'rmsprop'])
    parser.add_argument('--momentum', type=float, default=0.5)

    # ★ 三个改进的开关，通过命令行控制参与程度，方便消融实验
    parser.add_argument('--use_augment', action='store_true', help='使用温和数据增强')
    parser.add_argument('--use_dropout', action='store_true', help='在 fc1 后加 Dropout(0.25)')
    parser.add_argument('--use_scheduler', action='store_true', help='使用 StepLR 学习率衰减')

    parser.add_argument('--random_state', type=int, default=42)
    return parser

if __name__ == '__main__':
    parser = get_args_parser()
    args = parser.parse_args()

    torch.manual_seed(args.random_state)
    np.random.seed(args.random_state)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"设备: {device}")
    print(f"改进开关: augment={args.use_augment}, dropout={args.use_dropout}, scheduler={args.use_scheduler}")
    print(f"超参数: lr={args.lr}, epochs={args.epochs}, batch={args.batch_size}")

    # ---------- ★ 数据预处理（根据开关决定是否使用数据增强）----------
    # 测试集只做 ToTensor，不做增强
    test_transform = transforms.Compose([ transforms.ToTensor() ])

    if args.use_augment:
        # 温和增强：小角度旋转、平移、缩放，不进行水平翻转（避免类别混淆）
        train_transform = transforms.Compose([
            transforms.RandomAffine(degrees=5, translate=(0.05, 0.05), scale=(0.95, 1.05)),
            transforms.ToTensor(),
        ])
    else:
        train_transform = test_transform

    train_dataset = FashionDataset(args.train_dir, transform=train_transform)
    test_dataset = FashionDataset(args.test_dir, transform=test_transform)

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    print(f"训练集: {len(train_dataset)} 张, 测试集: {len(test_dataset)} 张")

    # ---------- ★ 模型（根据开关决定是否包含 Dropout）----------
    model = LeNet5_Plus(num_classes=10, dropout=args.use_dropout).to(device)
    criterion = nn.CrossEntropyLoss()

    # 优化器
    if args.optimizer == 'adam':
        optimizer = optim.Adam(model.parameters(), lr=args.lr)
    elif args.optimizer == 'sgd':
        optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum)
    elif args.optimizer == 'rmsprop':
        optimizer = optim.RMSprop(model.parameters(), lr=args.lr)

    # ★ 学习率调度器（如果启用）
    scheduler = None
    if args.use_scheduler:
        # 每 15 个 epoch 学习率乘以 0.5，使后期步长更小
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.5)
        print("启用 StepLR 调度器 (step_size=15, gamma=0.5)")

    # ---------- 训练 ----------
    train_losses, train_accs, test_accs = train_model(
        model, train_loader, test_loader, device, args.epochs, optimizer, criterion, scheduler
    )

    final_acc = test_accs[-1]
    print(f"\n最终测试集准确率: {final_acc:.2f}%")

    # 保存改进实验的训练曲线
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plt.plot(range(1, args.epochs+1), train_losses, 'b-o')
    plt.title('Training Loss')
    plt.grid(True)
    plt.subplot(1, 2, 2)
    plt.plot(range(1, args.epochs+1), train_accs, 'g-o', label='Train Acc')
    plt.plot(range(1, args.epochs+1), test_accs, 'r-o', label='Test Acc')
    plt.title('Accuracy')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plus_curves.png', dpi=150)
    plt.show()