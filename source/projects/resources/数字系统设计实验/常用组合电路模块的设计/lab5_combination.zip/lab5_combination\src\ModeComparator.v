module ModeComparator(a,b,m,y);
    input m;
    input [7:0] a,b;
    output [7:0] y;
    wire agb;
    comp #(.n(8))compare1(.a(a),.b(b),.agb(agb),.aeb(),.alb());
    wire addr;
    xnor_gate xnor1(.a(agb),.b(m),.out(addr));
    mux_2to1 #(.n(8))mux(.out(y),.in0(a),.in1(b),.addr(addr));
endmodule