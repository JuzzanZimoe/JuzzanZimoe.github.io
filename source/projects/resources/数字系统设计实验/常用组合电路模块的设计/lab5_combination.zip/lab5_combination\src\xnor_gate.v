module xnor_gate(a,b,out);
    input a,b;
    output reg out;
    always @ (*)begin
        case({a,b})
            2'b00:out=1;
            2'b01:out=0;
            2'b10:out=0;
            2'b11:out=1;
        endcase
    end
endmodule