module full_adder(a,b,s,ci,co);
    input a,b,ci;
    output s,co;
    assign {co,s}=a+b+ci;
endmodule