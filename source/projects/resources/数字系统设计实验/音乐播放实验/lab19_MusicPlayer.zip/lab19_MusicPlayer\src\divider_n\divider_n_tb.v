`timescale 1ns / 1ps
// 分频器测试：验证divider_n模块的1000分频功能及使能控制
module divider_n_tb;
    reg clk,en,rst;
    wire cout;
    // 实例化分频器：分频比1000，计数器位宽10（2^10=1024 > 1000）
    divider_n #(.n(1000),.counter_bits(10)) uut(.clk(clk),.en(en),.rst(rst),.cout(cout));
    // 产生100ns周期的时钟（10MHz）
    always #50 clk=~clk;
    initial
    begin
        clk=0;rst=0;en=0;  // 初始状态
        #(51)rst=1;
        #(100)rst=0;en = 1;  // 使能分频器
        #(200000);  // 等待一段时间观察cout输出（1000分频下，约每100µs一个脉冲）
        repeat(5)  // 反复开关使能，验证暂停/恢复计数功能
        begin 
            #(100000) en = 1;  // 使能持续100µs，期间分频器正常输出
            #(50000)  en = 0;  // 使能关闭50µs，分频器暂停
        end
        #100 $stop;  // 停止仿真
    end   
endmodule