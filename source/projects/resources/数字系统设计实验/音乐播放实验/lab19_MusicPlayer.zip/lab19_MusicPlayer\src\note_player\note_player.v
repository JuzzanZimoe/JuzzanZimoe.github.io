// 音符播放顶层模块：接收音符信息，控制DDS生成相应频率的正弦波，并在指定时长后请求下一音符
module note_player(clk,reset,play_enable,note_to_load,duration_to_load,
                    load_new_note,note_done,sampling_pulse,beat,sample,sample_ready);
    input clk,reset,play_enable,load_new_note,sampling_pulse,beat;
    input [5:0] note_to_load,duration_to_load;
    output note_done;
    output [15:0] sample;
    output sample_ready;
    wire load,timer_clear,timer_done;
    // 控制器：根据外界输入和定时完成信号，产生load脉冲和timer_clear、note_done
    note_player_controller note_player_controller_inst(.clk(clk),.reset(reset),
                        .play_enable(play_enable),.load_new_note(load_new_note),
                        .timer_done(timer_done),.timer_clear(timer_clear),.load(load),.note_done(note_done));
    // 节拍定时器：以beat为节拍，按duration_to_load给定的拍数计时
    beat_timer beat_timer_inst(.clk(clk),.beat(beat),.timer_clear(timer_clear),
                        .q(),.timer_done(timer_done),.duration_to_load(duration_to_load));
    wire [5:0] addr;
    // 寄存器：当load有效时，锁存待播放音符的note值，作为Frequency ROM的地址
    dff #(.WIDTH(6)) note_dff(.D(note_to_load),.Q(addr),.CLK(clk),.RST(~play_enable||reset),.EN(load));
    wire [19:0] k;
    // 频率查找表：根据音符标记addr输出对应的相位增量k（20位）
    frequency_rom frequency_rom_inst(.clk(clk),.addr(addr),.dout(k));
    // DDS模块：以22位相位增量生成正弦波采样数据，高位补两个0扩展至22位
    dds dds_inst(.k({2'b00,k}),.clk(clk),.reset(~play_enable||reset),.sampling_pulse(sampling_pulse),
                .sample(sample),.new_sample_ready(sample_ready));
endmodule