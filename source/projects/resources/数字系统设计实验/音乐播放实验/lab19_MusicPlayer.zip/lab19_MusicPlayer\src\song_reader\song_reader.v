// 乐曲读取顶层模块：根据乐曲编号和播放使能，从song_rom中读取音符并输出
module song_reader(song,clk,reset,note_done,play,note,duration,song_done,new_note);
    input clk,reset,play,note_done;
    input [1:0] song;
    output song_done,new_note;
    output [5:0] note,duration;
    wire co;  // 地址计数器进位
    wire [4:0] q;  // 当前音符在单首乐曲中的序号（0~31）
    // 控制器：根据play和note_done产生new_note脉冲
    song_reader_controller song_reader_inst(.clk(clk),.reset(reset),.note_done(note_done),.play(play),.new_note(new_note));
    // 地址计数器：note_done作为使能，读取下一个音符；模32，对应每首最⻓32个音符
    counter_n #(.n(32),.counter_bits(5)) counter_32(.clk(clk),.en(note_done),.rst(reset),.q(q),.cout(co));
    // 乐曲ROM：根据{song[1:0], q[4:0]}拼接的7位地址输出{note, duration}
    song_rom song_rom_inst(.clk(clk),.dout({note,duration}),.addr({song,q}));
    // 乐曲结束判断：当地址溢出(co)或当前duration=0时，产生song_done脉冲
    end_detector end_detector_inst(.clk(clk),.co(co),.duration(duration),.song_done(song_done));
endmodule