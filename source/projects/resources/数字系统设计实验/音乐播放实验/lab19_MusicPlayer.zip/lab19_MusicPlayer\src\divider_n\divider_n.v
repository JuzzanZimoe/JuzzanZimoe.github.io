// 参数化整数分频器：输出频率 = 输入时钟频率 / n（当使能有效时）
// 与计数器类似，但仅输出进位脉冲cout，不引出内部计数值
module divider_n(clk,en,rst,cout);
    parameter n=2;   // 分频比
    parameter counter_bits=1;  // 计数器位宽，需满足 2^counter_bits >= n
    input clk,en,rst;   // 使能（高有效）、复位（高有效）
    output cout;   
    reg [counter_bits-1:0] count=0;
    // 当计数值达到 n-1 且使能有效时，cout输出高电平脉冲
    assign cout=(count==(n-1))&&en;
    always@(posedge clk)
    begin
        if(rst) count=0;  // 同步复位
        else if(en)
        begin  // 使能有效时计数
            if(count==(n-1)) count=0;  // 计满回零
            else count=count+1;
        end
    end
endmodule