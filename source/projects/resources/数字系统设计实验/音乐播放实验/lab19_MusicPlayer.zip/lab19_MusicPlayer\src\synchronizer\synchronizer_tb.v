`timescale 1ns / 1ps

module synchronizer_tb;
    reg clk;
    reg in;
    wire out;
    synchronizer uut(.in(in),.clk(clk),.out(out));
    always #50 clk = ~clk;
    initial 
    begin
        clk=0;in=0;
        #(200);
        repeat(10)
        begin 
            #(100*3)in=1;
            #(100)in = 0;
        end
        #100 $stop;
   end
endmodule