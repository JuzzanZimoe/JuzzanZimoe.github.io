// 功能：参数化模n计数器，带使能和同步复位
// 参数 n：计数模值（计满n个时钟周期后回零）
// 参数 counter_bits：计数器位宽，需满足 2^counter_bits >= n
module counter_n(clk,en,rst,q,cout);
    parameter n=2;
    parameter counter_bits=1;
    input  clk,en,rst;     // 使能（高有效）、复位（高有效）
    output cout;           // 计数完成脉冲（q==n-1且en=1时输出1）
    output [counter_bits-1:0] q;  // 当前计数值
    reg [counter_bits-1:0] q=0;

    // 进位输出：计满且使能有效时产生一个时钟周期的高脉冲
    assign cout=(q==(n-1))&&en;
    always @(posedge clk) 
        begin
            if(rst)q=0;     // 同步复位，计数值清0
            else if(en)     // 使能有效时计数
                begin
                    if(q==(n-1))q=0;   // 计满回零
                    else q=q+1;
                end
        end
endmodule