module addr_process(raw_addr,rom_addr);
    input [10:0] raw_addr;
    output reg [9:0] rom_addr;
    always@(*)
    begin
        if(raw_addr[10]==0)
            rom_addr=raw_addr[9:0];
        else if(raw_addr[10]==1)
            rom_addr=1023-raw_addr[9:0];
    end
endmodule