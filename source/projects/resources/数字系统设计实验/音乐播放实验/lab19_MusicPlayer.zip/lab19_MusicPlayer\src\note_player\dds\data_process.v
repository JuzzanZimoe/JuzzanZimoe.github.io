module data_process(raw_data,area,data);
    input area;
    input [15:0] raw_data;
    output [15:0] data;
    assign data=area?(~raw_data+1'b1):raw_data;
endmodule