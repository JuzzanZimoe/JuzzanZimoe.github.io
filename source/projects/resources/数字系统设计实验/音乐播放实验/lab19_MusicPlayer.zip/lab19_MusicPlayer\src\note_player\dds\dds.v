module dds(k,clk,reset,sampling_pulse,sample,new_sample_ready);
    input [21:0] k;
    input clk,reset,sampling_pulse;
    output [15:0] sample;
    output new_sample_ready;
    wire [21:0] raw_addr,adder_sum;
    adder_Nbit #(.N(22)) adder_22bit(.a(k),.b(raw_addr),.sum(adder_sum));
    dff #(.WIDTH(22)) dff1(.D(adder_sum),.Q(raw_addr),.CLK(clk),.RST(reset),.EN(sampling_pulse));
    wire [9:0] rom_addr;
    addr_process apro(.raw_addr(raw_addr[20:10]),.rom_addr(rom_addr));
    wire [15:0] raw_data;
    sine_rom rom(.clk(clk),.addr(rom_addr),.dout(raw_data));
    wire area;
    dff #(.WIDTH(1)) dff2(.D(raw_addr[21]),.Q(area),.CLK(clk),.RST(0),.EN(1));
    wire [15:0] data;
    data_process dpro(.raw_data(raw_data),.area(area),.data(data));
    dff #(.WIDTH(16)) dff3(.D(data),.Q(sample),.CLK(clk),.RST(0),.EN(sampling_pulse));
    dff #(.WIDTH(1)) dff4(.D(sampling_pulse),.Q(new_sample_ready),.CLK(clk),.RST(0),.EN(1));
endmodule