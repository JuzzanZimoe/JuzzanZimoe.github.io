// 跨时钟域同步化电路：将异步输入脉冲转换为与clk同步的单周期脉冲
// 工作原理：两级同步寄存器消除亚稳态，再用边沿检测产生一个clk周期的正脉冲
module synchronizer(in,clk,out);
    input in,clk;  // 异步输入信号、目标时钟域时钟
    output out;
    wire q1,q2;  // 两级同步寄存器的输出
    // 第一级同步寄存器
    dff dff1(.D(in),.CLK(clk),.RST(0'b0),.EN(1'b1),.Q(q1));
    // 第二级同步寄存器
    dff dff2(.D(q1),.CLK(clk),.RST(0'b0),.EN(1'b1),.Q(q2));
    // 上升沿检测：q1为1且q2为0时，表明输入端刚出现上升沿，输出一个正脉冲
    assign out=q1&&~q2;
endmodule