// 乐曲读取状态机控制器：控制new_note脉冲的产生，协调ROM读取时序
module song_reader_controller(clk,reset,note_done,play,new_note);
    input clk,reset,note_done,play;
    output reg new_note;  // 新音符有效脉冲
    parameter RESET=0,NEW_NOTE=1,WAIT=2,NEXT_NOTE=3;
    reg [1:0] state,next_state;
    always@(posedge clk)
        if(reset)state<=RESET;
        else state<=next_state;
    always@(*)
    begin
        new_note=0;
        case(state)
            RESET:
                begin
                    if(play)next_state=NEW_NOTE;
                    else next_state=RESET;
                end
            NEW_NOTE:
                begin    // 输出一个周期的新音符脉冲
                    new_note=1;
                    next_state=WAIT;
                end
            WAIT:
                begin   // 等待当前音符播放结束
                    new_note=0;
                    if(play!=1)next_state=RESET;
                    else if(note_done!=1)next_state=WAIT;
                    else next_state=NEXT_NOTE;
                end
            NEXT_NOTE:
                begin   // 加入一个等待周期匹配ROM读取延时
                    new_note=0;
                    next_state=NEW_NOTE;
                end
            default:next_state=RESET;
        endcase
    end
endmodule