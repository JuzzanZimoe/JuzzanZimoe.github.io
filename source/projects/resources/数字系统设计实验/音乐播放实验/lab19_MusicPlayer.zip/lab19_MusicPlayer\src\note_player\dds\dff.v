module dff(D,Q,CLK,RST,EN);
    parameter WIDTH=1;
    input CLK,RST,EN;
    input [WIDTH-1:0] D;
    output reg [WIDTH-1:0] Q;
    always@(posedge CLK or posedge RST)
    begin
        if(RST) Q<='d0;
        else if(EN) Q<=D;
    end
endmodule