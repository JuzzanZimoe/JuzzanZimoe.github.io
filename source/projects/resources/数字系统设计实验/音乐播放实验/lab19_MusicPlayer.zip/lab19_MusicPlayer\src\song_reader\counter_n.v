// 参数化模n计数器，带使能和同步复位
module counter_n(clk,en,rst,q,cout);
    parameter n=2;
    parameter counter_bits=1;
    input  clk,en,rst;   // 使能（高有效）、复位（高有效）
    output cout;
    output [counter_bits-1:0] q;
    reg [counter_bits-1:0] q=0;
    assign cout=(q==(n-1))&&en;  // 计到n-1且使能有效时产生脉冲
    always @(posedge clk) 
        begin
            if(rst)q=0;  // 同步复位
            else if(en)
                begin
                    if(q==(n-1))q=0;
                    else q=q+1;
                end
        end
endmodule