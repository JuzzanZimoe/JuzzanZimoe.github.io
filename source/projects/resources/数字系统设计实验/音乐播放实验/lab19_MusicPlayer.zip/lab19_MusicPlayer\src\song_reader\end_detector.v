// 乐曲结束检测模块：当地址计数器进位(co)或当前音符duration=0时，生成song_done脉冲
module end_detector(clk,co,duration,song_done);
    input clk,co;
    input [5:0] duration;
    output reg song_done;
    parameter NOT_DONE=0,DONE=1;
    reg [1:0] state,next_state;
    always@(posedge clk)
        state<=next_state;
    always@(*)
    begin
        song_done=0;
        case(state)
            NOT_DONE:
                begin
                    if(duration==0||co)next_state=DONE;  // 无音符或地址溢出表示结束
                    else next_state=NOT_DONE;
                end
            DONE:
                begin
                    song_done=1;   // 输出结束脉冲
                    if(duration&&co==0)next_state=NOT_DONE;  // 恢复条件成立时退出DONE
                    else next_state=DONE;
                end
            default:next_state=NOT_DONE;
        endcase
    end
endmodule