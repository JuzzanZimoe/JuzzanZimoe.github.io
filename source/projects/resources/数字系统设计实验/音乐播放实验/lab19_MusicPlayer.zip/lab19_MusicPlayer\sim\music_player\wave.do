onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /music_player_tb_v/clk
add wave -noupdate /music_player_tb_v/reset
add wave -noupdate /music_player_tb_v/play_pause
add wave -noupdate /music_player_tb_v/next
add wave -noupdate /music_player_tb_v/NewFrame
add wave -noupdate /music_player_tb_v/play
add wave -noupdate /music_player_tb_v/song
add wave -noupdate -format Analog-Interpolated -height 50 -max 32767.0 -min -32768.0 -radix decimal /music_player_tb_v/sample
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {736895000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 189
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {2440880328 ps}
