onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /note_player_tb_v/clk
add wave -noupdate /note_player_tb_v/reset
add wave -noupdate /note_player_tb_v/play_enable
add wave -noupdate /note_player_tb_v/note_to_load
add wave -noupdate /note_player_tb_v/duration_to_load
add wave -noupdate /note_player_tb_v/load_new_note
add wave -noupdate /note_player_tb_v/beat
add wave -noupdate /note_player_tb_v/sampling_pulse
add wave -noupdate /note_player_tb_v/note_done
add wave -noupdate /note_player_tb_v/sample_ready
add wave -noupdate /note_player_tb_v/new_note1
add wave -noupdate /note_player_tb_v/new_note2
add wave -noupdate /note_player_tb_v/temp_1
add wave -noupdate /note_player_tb_v/temp_2
add wave -noupdate -format Analog-Interpolated -height 50 -max 32767.0 -min -32768.0 -radix decimal /note_player_tb_v/sample
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {9795000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 275
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {13750800 ps}
