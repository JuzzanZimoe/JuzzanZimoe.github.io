// 功能：音乐播放器主控制器顶层模块
// 例化状态机控制器(mcu_controller)和乐曲序号计数器，输出当前播放控制信号

module mcu(clk,reset,play_pause,next,song_done,play,reset_play,song);
    input clk,reset,play_pause,next,song_done;
    output play,reset_play;
    output [1:0] song;
    wire NextSong;
    // 控制器实例，根据按键和乐曲结束信号输出控制信号
    mcu_controller ctrl(.clk(clk),.reset(reset),.next(next),.song_done(song_done),.play_pause(play_pause),
                        .play(play),.reset_play(reset_play),.NextSong(NextSong));
    // 乐曲序号计数器：模4，位宽2，NextSong作为使能，每切一次歌序号加1
    counter_n #(.n(4),.counter_bits(2))cont(.clk(clk),.en(NextSong),.rst(reset),.q(song),.cout());  // 未使用进位输出
endmodule