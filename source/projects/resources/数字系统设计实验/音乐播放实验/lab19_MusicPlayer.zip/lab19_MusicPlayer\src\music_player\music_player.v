// 音乐播放器次顶层模块：将主控制器、乐曲读取、音符播放、同步化电路和节拍分频器
// 整合为一个整体，实现完整的音乐播放功能
module music_player(clk,reset,play_pause,next,NewFrame,sample,play,song);
    parameter sim=0;
    input clk,reset,play_pause,next,NewFrame;
    output [15:0] sample;
    output play;
    output [1:0] song;
    // 各子模块间的连接信号
    wire [5:0] duration,note;
    wire song_done,reset_play,note_done,new_note,ready,beat;
    // 主控制器：处理按键输入，输出播放使能和乐曲编号
    mcu mcu_inst(.clk(clk),.reset(reset),.play_pause(play_pause),.next(next),.song_done(song_done),
                .play(play),.reset_play(reset_play),.song(song));
    // 乐曲读取模块：根据乐曲编号和播放使能，从ROM中读取音符并发送
    song_reader song_reader_inst(.song(song),.clk(clk),.reset(reset_play),.note_done(note_done),.play(play),
                                .note(note),.duration(duration),.song_done(song_done),.new_note(new_note));
    // 音符播放模块：接收音符，控制DDS产生对应频率的正弦波
    note_player note_player_inst(.clk(clk),.reset(reset_play),.play_enable(play),.note_to_load(note),
                                .duration_to_load(duration),.load_new_note(new_note),.note_done(note_done),
                                .sampling_pulse(ready),.beat(beat),.sample(sample),.sample_ready());
    // 同步化电路：将音频接口的NewFrame脉冲同步到系统时钟域
    synchronizer synchronizer_inst(.in(NewFrame),.clk(clk),.out(ready));
    // 节拍基准产生器：对ready脉冲进行分频，产生48Hz的beat节拍
    // sim=1（仿真）时分频比为64，sim=0（板级）时分频比为1000
    divider_n #(.n(sim?64:1000),.counter_bits(sim?6:10)) divider_1000 (.clk(clk),.en(ready),.rst(0),.cout(beat));
endmodule