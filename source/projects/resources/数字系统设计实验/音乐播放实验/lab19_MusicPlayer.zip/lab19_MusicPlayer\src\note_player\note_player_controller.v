// 音符播放状态机控制器：管理音符装载、定时清零和音符完成信号的产生
// 状态说明：
//   RESET: 强制复位定时器并转入WAIT
//   WAIT:  等待定时完成(timer_done)或新音符装载请求(load_new_note)
//   DONE:  输出note_done脉冲，清除定时器，准备接收下一音符
//   LOAD:  输出load脉冲锁存新音符，清除定时器开始计时
module note_player_controller(clk,reset,play_enable,load_new_note,timer_done,timer_clear,load,note_done);
    input clk,reset,play_enable,load_new_note,timer_done;
    output reg timer_clear,load,note_done;
    parameter RESET=0,WAIT=1,DONE=2,LOAD=3;
    reg [1:0] state,next_state;
    always@(posedge clk)
        if(reset)state<=RESET;
        else state<=next_state;
    always@(*)
    begin
        timer_clear=0;load=0;note_done=0;
        case(state)
            RESET:
                begin
                    timer_clear=1;  // 清定时器
                    next_state=WAIT;
                end
            WAIT:
                begin
                    if(play_enable!=1)next_state=RESET;
                    else if(timer_done)next_state=DONE;   // 当前音符计时结束
                    else if(load_new_note)next_state=LOAD;   // 有新的音符待装载
                    else next_state=WAIT;
                end
            DONE:
                begin
                    timer_clear=1;note_done=1;  // 清除定时器，准备下一音符
                    next_state=WAIT;  // 通知song_reader取下一个音符
                end
            LOAD:
                begin
                    timer_clear=1;load=1;  // 装载新音符并清除定时器开始计时
                    next_state=WAIT;
                end
            default:next_state=RESET;
        endcase
    end
endmodule