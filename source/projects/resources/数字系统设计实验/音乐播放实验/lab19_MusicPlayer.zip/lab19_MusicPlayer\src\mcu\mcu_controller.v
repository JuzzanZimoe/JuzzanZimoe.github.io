// 功能：主控制器有限状态机，处理按键输入和乐曲结束信号，产生播放控制与切歌脉冲
// 状态说明：
//   RESET : 上电/复位态，输出复位脉冲，自动跳转到PAUSE
//   PAUSE : 暂停态，等待play_pause或next按键
//   PLAY  : 播放态，输出play=1；可由play_pause转入暂停，next切歌，song_done结束
//   NEXT  : 切歌态，产生NextSong脉冲并复位下游，然后自动进入PLAY
module mcu_controller(clk,reset,next,song_done,play_pause,play,reset_play,NextSong);
    input clk,reset,next,song_done,play_pause;
    output reg play,reset_play,NextSong;
    parameter RESET=0,PAUSE=1,PLAY=2,NEXT=3;
    reg [1:0] state,next_state;

    // 状态寄存器：同步复位，复位后进入RESET状态
    always@(posedge clk)
        if(reset)state<=RESET;
        else state<=next_state;

    // 下一状态产生逻辑 + 输出逻辑（组合逻辑）
    always@(*)
    begin
        // 默认输出值，避免生成锁存器
        play=0;reset_play=0;NextSong=0;
        case(state)
            RESET: begin reset_play=1;next_state=PAUSE;end  // 输出复位脉冲，初始化乐曲读取和音符播放模块
            PAUSE:
                begin
                    if(play_pause)next_state=PLAY;  // 按下播放/暂停键进入播放
                    else if(next)next_state=NEXT;   // 按下下一曲键进入切歌
                    else next_state=PAUSE;
                end
            PLAY:
                begin
                    play=1;  // 输出播放使能
                    if(play_pause)next_state=PAUSE;    // 再次按下播放/暂停暂停
                    else if(next)next_state=NEXT;   // 按下下一曲键切歌
                    else if(song_done)next_state=RESET;   // 当前乐曲播放完毕复位
                    else next_state=PLAY;
                end
            NEXT: begin NextSong=1;reset_play=1;next_state=PLAY;end
            default: next_state=RESET;   // 安全转移，避免状态机进入非法状态后无法恢复
        endcase
    end
endmodule