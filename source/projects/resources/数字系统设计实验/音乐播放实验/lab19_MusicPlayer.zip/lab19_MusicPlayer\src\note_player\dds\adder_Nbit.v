module adder_Nbit(a,b,sum);
    parameter N=1;
    input [N-1:0] a,b;
    output [N-1:0] sum;
    assign sum=a+b;
endmodule