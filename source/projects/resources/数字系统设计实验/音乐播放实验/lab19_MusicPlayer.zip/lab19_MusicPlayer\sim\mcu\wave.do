onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /mcu_tb_v/clk
add wave -noupdate /mcu_tb_v/reset
add wave -noupdate /mcu_tb_v/play_pause
add wave -noupdate /mcu_tb_v/next
add wave -noupdate /mcu_tb_v/song_done
add wave -noupdate /mcu_tb_v/play
add wave -noupdate /mcu_tb_v/song
add wave -noupdate /mcu_tb_v/reset_play
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {569200 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 193
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {720300 ps}
