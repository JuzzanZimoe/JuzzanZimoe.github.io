// 通用参数化D触发器：异步复位、使能控制，位宽可配置
module dff(D,Q,CLK,RST,EN);
    parameter WIDTH=1;
    input CLK,RST,EN;  // 时钟、异步复位（高有效）、使能（高有效）
    input [WIDTH-1:0] D;
    output reg [WIDTH-1:0] Q;
    always@(posedge CLK or posedge RST)
    begin
        if(RST) Q<='d0;  // 异步复位
        else if(EN) Q<=D;  // 使能有效时更新输出
    end
endmodule