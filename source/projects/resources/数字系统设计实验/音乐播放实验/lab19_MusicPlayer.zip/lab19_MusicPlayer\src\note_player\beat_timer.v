// 音符节拍定时器：以beat脉冲为时基，计时时长由duration_to_load决定
// 当计数值达到 duration_to_load-1 时，输出timer_done脉冲（宽度为一个clk周期）
module beat_timer(clk,beat,timer_clear,q,timer_done,duration_to_load);
    input clk,beat,timer_clear;
    input [5:0] duration_to_load;
    output timer_done;
    output reg [5:0] q=0;
    // 当计数到目标值且beat有效时，timer_done=1
    assign timer_done=(q==(duration_to_load-1))&&beat;
    always@(posedge clk)
    begin
        if(timer_clear)q<=0;  // 清零信号有效时复位计数器
        else if(beat)  // 每次beat脉冲到来时计数
        begin
            if(q==(duration_to_load-1))q<=0;  // 计满回零
            else q<=q+1;
        end
    end
endmodule